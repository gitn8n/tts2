---
name: Feature request
about: Suggest an improvement or new feature for the web UI
title: ''
labels: 'enhancement'
assignees: ''

---

**Description**

A clear and concise description of what you want to be implemented.

**Additional Context**

If applicable, please provide any extra information, external links, or screenshots that could be useful.
